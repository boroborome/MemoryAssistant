
The Rule Expression
1. The value can be used in expression are number,string,and attribute of event.
   The number is a decimal number, and can not be negative.
   The string is a char sequence with (") at the begin and end.
   The attribute list conntains:
      eventid:It's a number, the same with starttime.
      starttime:It's a number.It's the timestamp of event when the event begin.
      title:It's a string.Usually, it's the text on the top of window.
      procid:It's a number.You can find it in taskmgr.
      procname:It's a string.It's the program name which you run
      lasttime:It's a number.It's the time you use the programe
      remark:It's a string.It's a text which you write yourself for remembering something.
      
2. Operators supported are "And","or","like","=", and ignore operator case.
   = : It means both value should be the same.
   !=   :It means the two value are not same.
   like : It's used with string value only, and it mean the first string contains the second string.The second string can contains wild char(*).
   and : It means both expression should be true.
   or  : It means either expression be true, the result will be true.
   
Examples:
procname="notepad.exe" and title like "*Hello*"
   